<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Online Shopping</title>
        <link rel="stylesheet" type="text/css" href="styles-header.css"/>
        <link rel="stylesheet" type="text/css" href="styles-login-signup.css"/>
        <link rel="stylesheet" type="text/css" href="styles-footer.css"/>
        <script type="text/javascript" src="Validation.js"></script>
    </head>

    <body>
        <header>
            <div id="Start"></div>
            <div class="header_title"></div>
            <div class="header">
                <div class="header_button">
                    <?php
                        if (!isset($_SESSION['loginUser'])) {
                            echo '<a class="home_button" href="home.php"><button>HOME</button></a>';
                        }
                        else if (isset($_SESSION['loginUser']) && $_SESSION['loginRank'] == "User") {
                            echo '<a class="home_button" href="home.php"><button>HOME</button></a>';
                        }
                        else if (isset($_SESSION['loginUser']) && $_SESSION['loginRank'] == "Admin") {
                            echo '<a class="home_button" href="admin.php"><button>HOME</button></a>';
                        }
                    ?>
                    <a class="contact_button" href="#Contacts"><button>CONTACT</button></a><br />
                </div>
                <div class="bottom_bar"><br /></div>
            </div>
    	</header>
        <!--header-->

        <!--main-->
        <main>
            <div class="main">
                <div class="signup_title">
                    <h1>Sign up</h1><br />
                </div>
                <div class="signup_main_form">
                    <?php
                        if (isset($_GET['signup_status'])) {
                            if ($_GET['signup_status'] == "success") {
                                echo '<div class="signup_status_success">
                                        <p>You successfully registered your account!</p>
                                    </div>';
                            }
                            else if ($_GET['signup_status'] == "duplicateEmail") {
                                echo '<div class="signup_status_failed">
                                        <p>Email already registered.</p>
                                    </div>';
                            }
                        }
                    ?>
                    <form class="signup_form" name="FormSignUp" action="signup_verify.php" method="post" onsubmit="return ValidateSignUp()">
                        <label>Username</label>
                        <input type="text" class="userInput" name="Name" />
                        <label>Mobile Number</label>
                        <input type="text" class="userInput" name="MNumber" />
                        <label>Email</label>
                        <input type="text" class="userInput" name="Email" />
                        <label>Password</label>
                        <input type="password" class="userInput" name="Password" id="PasswordInput" />
                        <label>Confirm Password</label>
                        <input type="password" class="userInput" name="CPassword" id="ConfirmPassword" />
                        <input type = "checkbox" onclick = "PasswordToggle()"><label> Show Password</label></input><br />
                        <button type="submit" name="signup_submit">Sign Up</button>
                        <button type="reset">Clear</button>
                    </form>
                    <p>
                		<br />Already have an account ?<br /><a href="login.php">Log in your account</a>
                	</p>
                </div>
            </div>
        </main>
        <!--main-->

        <!--footer-->
        <footer class="footer">
            <div class="footer_main">
                <div class="footer_column">
                    <h4 id="Contacts"><b>Contact</b></h4>
                    <p>Questions? Go ahead.</p>
                    <form action="/action_page.php" target="_blank">
                        <p><input type="text" placeholder="Name" name="Name" required></p>
                        <p><input type="text" placeholder="Email" name="Email" required></p>
                        <p><input type="text" placeholder="Subject" name="Subject" required></p>
                        <p><input type="text" placeholder="Message" name="Message" required></p>
                        <button type="submit">Send</button>
                    </form>
                </div>

                <div class="footer_column">
                    <h4><b>About</b></h4>
                    <p><a href="#">About us</a></p>
                    <p><a href="#">We're hiring</a></p>
                    <p><a href="#">Support</a></p>
                    <p><a href="#">Find store</a></p>
                    <p><a href="#">Shipment</a></p>
                    <p><a href="#">Payment</a></p>
                    <p><a href="#">Gift card</a></p>
                    <p><a href="#">Return</a></p>
                    <p><a href="#">Help</a></p>
                </div>

                <div class="footer_column_2">
                    <h4><b>Store</b></h4>
                    <p>Company Name</p>
                    <p>0044123123</p>
                    <p>@mail.com</p><br />
                    <h4><b>We accept</b></h4>
                    <p>Online Banking</p>
                    <p>Credit Card</p>
                </div>
                <a href ="#Start"><img src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANEAAADRCAMAAABl5KfdAAAAMFBMVEX///9mZmZ6enpwcHDr6+vW1tb19fXMzMytra3g4OCPj4+4uLiZmZnCwsKjo6OFhYWSx0fiAAAK70lEQVR4nN2d2WLrKgxFW88T9v//7U2apEk0gCQkp+fu1za2lyWEwCC+vgI1zH1ap635fqjZpjX18xB50xgNXZ+m7Wia9hurbZpjm1Lf/Stg3TgtDQGC1SzT2H36cQvq0n6IYF6w9vRXqYZ+0tI8dEz9n/PAYdxlnsaaahv/ElRfiXNTu/efBrmpWz1wbmqmz7epfnPDuWkbP4kzJGssyOlIn2pRg6O7vatZP8EUx/MhphTJc2M6lWeMaD9Qx3kxYl5O4LlqmU/hGXbxEzXHsk8pjf08d103z+N4GVzsyyH32P2E5jSKHqc99sw46DrY2BdqpIFfSrTrdYIOtdlW0ZhumNMmeD1baBqRSu+1XVad789r0VZtnJmGgoFaW/48jFsBKqo19XkXWSqGAyWoJiQrX7O3XGu9vZDC+/e3WY9bfDx9zPVzm7PndZkkYfPrB+fMeztcY17Pe/nu26/PfP/dOjamdIZ9HsrYKXndY+LusMRMDPRse5p8bsD5QWCCwqZau8fVOSeYIpPIgfOLrf7ajAcc0Yn+zETXpfJFDgzQGQNMpkuvRKKBwg10E2OmpeaaNJA6cRzG/WiaRZ0pMYPLCiQ6KKh7hecsi7r7oocv5vBAvqFG+1DvCZS2R5nJOG4M4mQAVbdLmEAtStejY5OpqyVTH/XL6bGRta2JdBVDQoQf5dsQtKmrqJHIMK5OwDqqSapfDPla9EiUu7Ra7yUapD6bH0kgA9JIvN9D16KJuK0Hoi1kQqIGaKoYTnhuq84TeCAD0kwgKVo18Sx6IM7lrFYiLiJ+JqoRqcdCeSBLWyKuIW1KRCNSR7kSkE/EEzYl4mFc+qFqJKJ1i1xnwG3QIVNwQcLZQyvxO+xz6uxdBmRAwjmewO+wz4nbnxZIj0TErKLf4d+o47YcSI806983dlVtmNMA6ZFwwCs0cvwOtFFBB6RHwq8870Oo6WkbkRZIjYSbRTZw4bCgbER6IDUSdqNccED8yq7VAqRGQh1tw/8vanbHGUBqJDSNxwYvnC3ofM4KpEVCfsc2dmRO3YyLHUiLhGapmMaBTKSLczVASiQU75j0DplINSaqA1IioZhMGgmBqxLUWiAlEuw3yXCHAp0mLNQD6ZBQcKDCHYyJmqkWDyAdEhzzEP0MeijF5X2AVEjISHjuDUIrMlQvIBUSfF7kUh28uPzafkAaJGQk+EvYaclbkSeQBgkaCQZwGLrFgc4XSIEEjQQCOHwucV/kDaRAgn3Se2yAI0NpuuAPJEeCicNbLIMpXWbEoQFitiW1U34VpxQJXP0tuYO4woFeAWjCI8j7rQs/FCLBRPTVsWDckF2xCPRF26Ltcgv25Eiwx3lxO+h0srhQBiImnO9EpR/LkEBseBn9wMuL4kIZKGOj7LJKMRJMrp/RDnSvoulxCVCOyAMJ+sBzzA3Sbkm+IALKEnk4Hmj/vwk4bGECp5MB5YkcrARj9OMXwB0FTicEKhDVWwm63cMWIGEoR7rCJ8mnOxeI6q0Eot0jfoN+sNi9Si1UJqq2Euhk7w0JNqNS2i0HKhPVWgkk4PcrAx8q5XQKIC4Len3MSiRwh1tDAr1RIXZrgAQ2qkUC8ft2e9C68s1IHBTERHVIoCHdohowXHZBk8pCQqIqJPBAP00GBIZsb1SwEDKvjKgGCfZIHabMfTJSWkhMVBPEQQZ39TCQMWTm6XRtSENUYSWQHlxni0Go4wODHkgSvR9I+YvzSCA0XJ8CxD82MBiAFERmK4FXce17gCNyv7QAaYisVgJZw4I+G3GhTh0U1EQlKzEhCwS7Y4DL+JnfkYuli0A6ohKS6K1dTAkWHjNDiXxFBvYLtI6o5Aj0z94fre1lwTvfiPhP6kqigpXoZwORLVHRDytbBCSzRkBLlLcS3cZB75NE3RFeiiMD0hPlrUROgACTrFSfi8Tv8C2s4tATZa1E3gs1G+BQ5Gtgt/iWlqUYiHJWIsNWgv8DfkSmDDxRYZ2NhShjJZIIRK22jqi0cMhExFuJJIIvABKR0yZcsYniSigbEYtEhm8YtkRETHdUXtplJOKQyEZuIkJLA4RAZiIaie6P4MOJiMiNsZLFd2YiMjzQd7QREYmqaDWhnYiwErPcr+R1zIAP9bGyL7UVRKiYD7c3oBTruCHse7iTllmqIfrq3rJqdq806o/IaVZCrzu8xaWwqojeyv7t7G8A0YKTcU7dfmNqN/mmy0qiy+PuR9s2S64oKcrrxFNB16IE67qqaiNXE13vOuS/0KHcWzQ+ssqDqCQ0PgJGc6iM8qIziFCz6UXzDEadQYTmGWRzQUadQQTmgmbpfJ3H3UKIwHzdNbEAE1eB7y+ECM+piue9LTqBiJj3VnRIap1ARPQ+8u9Hep1ARMxlKb7xqXUCEfGNT/MdVqt4Iuo7LLytZ02teCLqW7luPYNO8UQgMNySON2aE5Xiicg1J8p1QRrFE5HLS7Rrt+z38yei126p19fJFU5Er6/Tr4EUK5yIWQOpX6cqVTQRt07VsJZYqGgibi2xZb23TNFE3Hpv05p8kYKJ+DX5pn0TEgUT8fsmbHtbBAomgntbXv5k239UVixRZv+RdY9YUeIVgybBz8OvEwrWfXwlxRIBD3j/vmTda1lQKFF2r6V9P2xeoUT5/bD2PctZRRIV9iyjJQs+eUMkUWlfecXe/4wCiYp7/2vqM/AKJCrWZ6iqocEqjkhQQ6OqzgmnOCJBnZO6WjSMwohEtWjq6gXRCiOCDkUnOXU1nUhFEclqOtXW3aIURCStu1VbG41QEBGqBcmNFWrr12HFjI/k9euqawwixRDJawwST1DpdyFEaB1wbjRXXasTKIJIV6uzvp7quwKIlPVUHWrevimASFvz1qEu8av8ifAWjlJTJ+pNVzQldyJD7WiP+t5P0fuW7ESW+t4uNdh/RW+Ws8+rm2qwu9TJf4g+Y8o8G2isk+9ylsFd9FYsq82tZxmQb9YY8OgNF8b3Q7weqfO4nAlyE9mQbIGh5kwQcieibd0dtc/H1iqrzm2hz9axIWEj2WI3BaTyXmp7jgkJ74ox+S9la91k1UD1jaZngQcXmcICBaQ8o8rpHLGr3pZft6ZLeJwj5nXW21XDbyHL1nY+vM9Zb17n8f1oGKdlWfZkC9te5/F5nZlYK8czE73OtayT67mWbmePVohODCs+MjidD2uV//mw3KHETcyp3lBwt6UDEH/Osu9WMlrM/vyoo6M/dxZ2/aX/d+eVZ86Ujwt6iW5BbvtU2IITS0yE6NnqRG7Nl6/coj7cuqyZc3PXnjBTTWX3ZZo5HzePObkbZWogKXZll9Tz9vk+XHcYXoJP5l7fi8/itTFX3WvzD61c+ZYfNWvtG+xWLr79yHV74UNMUvJrqGR/i0PKF1+LSviZxPFX7TZaoLq05QvXRabGqXDr73ZZda9zXpfiNf12PRDqcgHirmZbe8lLHfp1yzvyj2xzEwqNgoe4vNdjX/uZ4xrmft2Pkm1uryfUQPfHKbSmV65m2fY1pbGfu26e+zGlddoXGcuPQtPhp+Z8YPLTct6cxpgto+ik4wSHexGb73spcKzCaMj38bU869nzgrFMn+H5YUoR7emoSKcclMv/TXIcm1hVSJpVqk/hndQzB4YpcfbPm+epYayEuuB8tPVQGvrJGieO6e/h3NUlYQL6q0tKq6q29gl147TIPLBZpj9P86uuT9O2HA1ZRLS5pORT6v8ZmBcNXT+u6/4cpR4XkpEfN7noP5TFa8aMTfg9AAAAAElFTkSuQmCC" width = "50" height = "50" align = "right" alt = "ReturnTop">
                </a>
            </div>
        </footer>
    </body>

</html>
