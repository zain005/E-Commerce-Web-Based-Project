<?php
    if (isset($_POST['addproduct_submit'])) {
        include_once "connect.php";
        session_start();
        ob_start();
        
        $table = "productlist";

        if (!$connection) {
            echo "Could not connect to server.<br />Error : " . mysqli_connect_error();
        }
        else {
            if (!mysqli_select_db($connection, $db)) {
                echo "Error : ". mysqli_error($connection) . "<br />";
            }
        }

        $userID = $_SESSION['loginUserID'];
        $productID = $_GET['product'];
        $query = "SELECT `Product Name`, `Product Type`, `Price(RM)` FROM $table WHERE productID='$productID'";
        $result = mysqli_query($connection, $query);
        $row = mysqli_fetch_assoc($result);

        if (!$result) {
            echo "Cannot add Item.";
        }
        else {
            $table = "cartlist";
            $productName = $row['Product Name'];
            $productType = $row['Product Type'];
            $quantity = $_POST['quantity'];
            $price = $row['Price(RM)'];
            $query = "INSERT INTO $table (`userID`, `productID`, `Product Name`, `Product Type`, `Quantity`, `Price(RM)`) VALUES"
                . "($userID, $productID, '$productName', '$productType', $quantity, $price);";
            $result = mysqli_query($connection, $query);

            if (!$result) {
                echo "Cannot add Item.";
            }
            else {
                mysqli_close($connection);
                header("Location: home.php?addItem_status=success");
                ob_end_flush();
                exit();
            }
            mysqli_close($connection);
        }
    }
    else {
        header("Location: home.php");
        ob_end_flush();
        exit();
    }
?>
