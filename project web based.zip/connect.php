<?php
    $host = "localhost";
    $user = "id11856671_julian";
    $password = "9081211a";
    $db = "id11856671_project";
    $table = "userlist";

    $connection = mysqli_connect($host, $user, $password);
?>
