<?php
    if (isset($_POST['pay_submit'])) {
        session_start();
        ob_start();
        include "connect.php";

        $table = "bankaccount";
        if (!$connection) {
            echo "Could not connect to server.<br />Error : " . mysqli_connect_error();
        }
        else {
            if (!mysqli_select_db($connection, $db)) {
                echo "Error : ". mysqli_error($connection) . "<br />";
            }
        }

        $cardname = $_POST['cardname'];
        $cardnumber = $_POST['cardnumber'];
        $expirymonth = $_POST['expirymonth'];
        $expiryyear = $_POST['expiryyear'];
        $cvv = $_POST['cvv'];
        $totalprice = $_POST['pay_submit'];
        $_SESSION['tax'] = 0.06;

        $query = "SELECT `Card Name`,`Card Number`, `Expire Month`, `Expire Year`, `CVV`, `Amount(RM)` FROM $table WHERE
                `Card Name`='$cardname' AND `Card Number`=$cardnumber AND `Expire Month`=$expirymonth AND `Expire Year`=$expiryyear
                AND `CVV`=$cvv;";
        $result = mysqli_query($connection, $query);
        $row = mysqli_fetch_assoc($result);

        if (!($row['Card Name'] == $cardname && $row['Card Number'] == $cardnumber && $row['Expire Month'] == $expirymonth && $row['Expire Year'] == $expiryyear && $row['CVV'] == $cvv)) {
            mysqli_close($connection);
            header("Location: billing.php?payment_status=0");
            ob_end_flush();
            exit();
        }
        else if ($row['Amount(RM)'] < ($totalprice + ($totalprice * $_SESSION['tax']))) {
            mysqli_close($connection);
            header("Location: billing.php?payment_status=1");
            ob_end_flush();
            exit();
        }
        else {
            $amount = $row['Amount(RM)'];
            $amount -= $totalprice + ($totalprice * $_SESSION['tax']);
            $query = "UPDATE $table SET `Amount(RM)`=$amount WHERE`Card Name`='$cardname' AND `Card Number`=$cardnumber AND `Expire Month`=$expirymonth AND `Expire Year`=$expiryyear
                    AND `CVV`=$cvv;";
            $result = mysqli_query($connection, $query);
            if (!$result) {
                echo "Error : " . mysqli_error($connection) . "<br />";
            }

            $table = "orders";
            if (!$connection) {
                echo "Could not connect to server.<br />Error : " . mysqli_connect_error();
            }
            else {
                if (!mysqli_select_db($connection, $db)) {
                    echo "Error : ". mysqli_error($connection) . "<br />";
                }
            }

            $userID = $_SESSION['loginUserID'];
            $_SESSION['billFullname'] = $_POST['firstname'];
            $_SESSION['billEmail'] = $_POST['email'];
            $_SESSION['billAddress'] = $_POST['address'];
            $_SESSION['billCity'] = $_POST['city'];
            $_SESSION['billState'] = $_POST['state'];
            $_SESSION['billZip'] = $_POST['zip'];
            $amount_paid = $totalprice + ($totalprice * $_SESSION['tax']);
            $query = "SELECT orderID FROM $table;";
            $result = mysqli_query($connection, $query);
            $row = mysqli_fetch_assoc($result);
            if (mysqli_num_rows(mysqli_query($connection, $query)) == 0) {
                $query = "INSERT INTO $table VALUES "
                    ."(1, '$userID', $amount_paid);";
            }
            else {
                $query = "INSERT INTO $table VALUES "
                    ."(NULL, '$userID', $amount_paid);";
            }
            $result = mysqli_query($connection, $query);
            $orderID = mysqli_insert_id($connection);
            if (!$result) {
                echo "Error : " . mysqli_error($connection) . "<br />";
            }
            else {
                $table = "cartlist";
                $query = "SELECT userID, productID, `Product Name`, `Price(RM)`, Quantity FROM $table WHERE userID='$userID';";
                $result = mysqli_query($connection, $query);

                $array_product = array();
                $array_price = array();
                $array_quantity = array();
                while ($row = mysqli_fetch_assoc($result)) {
                    $productID = $row['productID'];
                    $productname = $row['Product Name'];
                    $price = $row['Price(RM)'] * $row['Quantity'];
                    $quantity = $row['Quantity'];
                    array_push($array_product, $productname);
                    array_push($array_price, $price);
                    array_push($array_quantity, $quantity);
                    $query = "INSERT INTO orderlist (orderID, userID, productID, Quantity) VALUES ('$orderID','$userID', '$productID', '$quantity');";
                    $result_order = mysqli_query($connection, $query);
                    if (!$result_order) {
                        echo "Error : " . mysqli_error($connection) . "<br />";
                    }
                }
                $_SESSION['array_product'] = $array_product;
                $_SESSION['array_price'] = $array_price;
                $_SESSION['array_quantity'] = $array_quantity;
                $_SESSION['orderID'] = $orderID;
                $_SESSION['totalprice'] = $totalprice;

                $query = "SELECT userID FROM $table WHERE userID='$userID';";
                $result = mysqli_query($connection, $query);

                while ($row = mysqli_fetch_assoc($result)) {
                    $query = "DELETE FROM $table WHERE userID='$userID';";
                    $result_delete = mysqli_query($connection, $query);
                    if (!$result_delete) {
                        echo "Error : " . mysqli_error($connection) . "<br />";
                    }
                }
                mysqli_close($connection);
                header("Location: receipt.php");
                ob_end_flush();
                exit();
            }
        }
    }
    else {
        header("Location: home.php");
        ob_end_flush();
        exit();
    }
?>
