<?php
    if (isset($_GET['delete_submit'])) {
        include_once "connect.php";
        session_start();
        ob_start();
        
        $table = "cartlist";

        if (!$connection) {
            echo "Could not connect to server.<br />Error : " . mysqli_connect_error();
        }
        else {
            if (!mysqli_select_db($connection, $db)) {
                echo "Error : ". mysqli_error($connection) . "<br />";
            }
        }
        $userID = $_SESSION['loginUserID'];

        $deleteProductID = $_GET['delete_submit'];
        $query = "SELECT userID, productID, `Product Name`, `Product Type`, `Quantity`, `Price(RM)` FROM $table WHERE userID='$userID' AND productID='$deleteProductID'";
        $result = mysqli_query($connection, $query);

        if (mysqli_num_rows($result) == 0) {
            echo "Error : Nothing To Delete.";
        }
        else {
            $query = "DELETE FROM $table WHERE userID='$userID' AND productID='$deleteProductID'";
            $result = mysqli_query($connection, $query);
            if ($result) {
                mysqli_close($connection);
                header("Location: cartItem.php");
                ob_end_flush();
                exit();
            }
            else {
                echo "Cannot delete item";
                mysqli_close($connection);
                header("Location: cartItem.php");
                ob_end_flush();
                exit();
            }
        }
    }
    else {
        header("Location: home.php");
        ob_end_flush();
        exit();
    }
?>
