<?php
    if (isset($_POST['update_user_submit'])) {
        include_once "connect.php";
        session_start();
		ob_start();

        $query = "USE $db;";

        if (!mysqli_query($connection, $query)) {
			die("Unable to connect to database!<br />Error : " .mysqli_error($connection));
			mysqli_close($connection);
		}
		else {
            $userID = $_SESSION['loginUserID'];
            $name = $_POST['Name'];
            $mnumber = $_POST['MNumber'];
            $email = $_POST['Email'];

            $query = "SELECT userID, Name, `Mobile Number`, Email FROM $table WHERE userID='$userID'";
            $result = mysqli_query($connection, $query);
            $row = mysqli_fetch_assoc($result);

            if (!$result) {
                die("Unable to get verify!<br />Error : " .mysqli_error($connection));
                mysqli_close($connection);
            }
            else {
                $query = "UPDATE $table SET Name='$name', `Mobile Number`='$mnumber', Email='$email' WHERE userID='$userID';";
                $result = mysqli_query($connection, $query);

                if (!$result) {
					die("Unable to update!<br />Error : " .mysqli_error($connection));
					mysqli_close($connection);
				}
                else {
                    $_SESSION['loginUser'] = $_POST['Name'];
                    $_SESSION['loginMobileNo'] = $_POST['MNumber'];
                    $_SESSION['loginEmail'] = $_POST['Email'];

                    mysqli_close($connection);
                    header("Location: account.php");
                    ob_end_flush();
                    exit();
                }
            }
        }
	}
	else {
		header("Location: account.php");
		ob_end_flush();
		exit();
	}
?>
