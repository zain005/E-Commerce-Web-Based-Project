<?php
    if (isset($_POST['signup_submit'])) {
        include_once "connect.php";
        include_once "createDB.php";
        ob_start();

        $Name = mysqli_real_escape_string($connection, $_POST['Name']);
        $MNumber = mysqli_real_escape_string($connection, $_POST['MNumber']);
        $Email = mysqli_real_escape_string($connection, $_POST['Email']);
        $Rank = "User";
        $Password = password_hash($_POST['Password'], PASSWORD_DEFAULT);


        $query = "SELECT Email FROM $table WHERE Email='$Email' AND `Rank`='$Rank';";
        if (mysqli_num_rows(mysqli_query($connection, $query)) > 0) {
            mysqli_close($connection);
            header("Location: signup.php?signup_status=duplicateEmail");
            exit();
        }
        else {
            $query = "SELECT userID FROM $table;";
            if (mysqli_num_rows(mysqli_query($connection, $query)) == 0) {
                $query = "INSERT INTO $table VALUES "
                    ."(1, '$Name', '$MNumber', '$Email', '$Rank', '$Password');";
            }
            else {
                $query = "INSERT INTO $table VALUES "
                    ."(NULL, '$Name', '$MNumber', '$Email', '$Rank', '$Password');";
            }

            if (!mysqli_query($connection, $query)) {
                echo "Error : " . mysqli_error($connection) . "<br />";
            }
            else {
                echo "Successfully added Data<br />";
            }
            mysqli_close($connection);
            header("Location: signup.php?signup_status=success");
            ob_end_flush();
            exit();
        }
    }
    else {
        header("Location: signup.php");
        ob_end_flush();
        exit();
    }
?>
