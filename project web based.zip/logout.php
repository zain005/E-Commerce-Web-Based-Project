<?php
    session_start();
    if (isset($_POST['logout_submit'])) {
        session_unset();
        session_destroy();
        header("location: home.php");
        exit();
    }
    else {
        header("Location: home.php");
        exit();
    }

?>
