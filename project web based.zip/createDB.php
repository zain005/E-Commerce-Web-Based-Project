<?php
    if (!$connection) {
        echo "Could not connect to server.<br />Error : " . mysqli_connect_error();
    }
    else {
        if (!mysqli_select_db($connection, $db)) {
            echo "Error : ". mysqli_error($connection) . "<br />";
            $query = "CREATE DATABASE $db;";

            if (!mysqli_query($connection, $query)) {
                echo "Error : " . mysqli_error($connection) . "<br />";
            }
            else {
                mysqli_select_db($connection, $db);
            }
        }

        $query = "DESCRIBE $table;";
        if (!mysqli_query($connection, $query)) {
            echo "Error : " . mysqli_error($connection) . "<br />";
            $query = "CREATE TABLE $table ("
                . "userID INT UNSIGNED NOT NULL    AUTO_INCREMENT,"
                . "`Name`   VARCHAR(100)  NOT NULL    DEFAULT '',"
                . "`Mobile Number`  VARCHAR(20)  NOT NULL    DEFAULT 0,"
                . "`Email`   VARCHAR(100)  NOT NULL    DEFAULT '',"
                . "`Rank`   VARCHAR(5)  NOT NULL    DEFAULT 'User',"
                . "`Password`   VARCHAR(100)  NOT NULL    DEFAULT '',"
                . "PRIMARY KEY  (userID)"
                . ");";

            if (!mysqli_query($connection, $query)) {
                echo "Error : " . mysqli_error($connection) . "<br />";
            }
        }
    }
?>
