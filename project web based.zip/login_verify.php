<?php
	if (isset($_POST['login_submit'])) {
		include_once "connect.php";
		ob_start();

		$query = "USE $db;";

		if (!mysqli_query($connection, $query)) {
			die("Unable to connect to database!<br />Error : " .mysqli_error($connection));
			mysqli_close($connection);
		}
		else {
			if (!$_POST['emailLogin'] == "" && !$_POST['passwordLogin'] == "") {
				$emailLogin = $_POST['emailLogin'];
				$passwordLogin = $_POST['passwordLogin'];
				$rank = $_POST['login_rank'];
				$query = "SELECT userID, Name, `Mobile Number`, Email, `Rank`, Password FROM $table WHERE Email='$emailLogin' AND `Rank`='$rank'";
				$result = mysqli_query($connection, $query);
				$row = mysqli_fetch_assoc($result);

				if (!$result) {
					die("Unable to get verify!<br />Error : " .mysqli_error($connection));
					mysqli_close($connection);
				}
				else if ($row['Email'] != $emailLogin || ($rank == "User" && $row['Rank'] == "Admin")) {
					mysqli_close($connection);
					header("Location: login.php?login_status=emailnotfound");
					ob_end_flush();
					exit();
				}
				else if ($rank == "Admin" && $row['Rank'] == "User") {
					mysqli_close($connection);
					header("Location: login.php?login_status=adminEmailNotValid");
					ob_end_flush();
					exit();
				}
				else if (!password_verify($passwordLogin, $row['Password'])) {
					mysqli_close($connection);
					header("Location: login.php?login_status=wrongPassword");
					ob_end_flush();
					exit();
				}
				else if ($rank == "User" && $row['Rank'] == "User") {
					session_start();
					$_SESSION['loginUserID'] = $row['userID'];
					$_SESSION['loginUser'] = $row['Name'];
					$_SESSION['loginMobileNo'] = $row['Mobile Number'];
					$_SESSION['loginEmail'] = $row['Email'];
					$_SESSION['loginRank'] = $row['Rank'];
					mysqli_close($connection);
					header("Location: home.php");
					ob_end_flush();
					exit();
				}
				else if ($rank == "Admin" && $row['Rank'] == "Admin") {
					session_start();
					$_SESSION['loginUserID'] = $row['userID'];
					$_SESSION['loginUser'] = $row['Name'];
					$_SESSION['loginMobileNo'] = $row['Mobile Number'];
					$_SESSION['loginEmail'] = $row['Email'];
					$_SESSION['loginRank'] = $row['Rank'];
					mysqli_close($connection);
					header("Location: admin.php");
					ob_end_flush();
					exit();
				}
			}
		}
	}
	else {
		header("Location: login.php");
		ob_end_flush();
		exit();
	}
?>
