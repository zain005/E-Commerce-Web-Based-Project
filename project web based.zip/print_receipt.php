<?php
    session_start();
    require "fpdf.php";

    class PDF extends FPDF {
        function header() {
            $this->Image("title.png", 30, 15);
            $this->setFont("Arial", "B", "18");
            $this->Cell(190, 80, "Customer Receipt", 0, 0, "C");
            $this->Ln();
            $this->header_line();
            $this->setFont("Times", "B", 16);
            $this->SetXY(20, 60);
            $this->Cell(50, 10 , "Name : ", 0, 0, "L");
            $this->Cell(120, 10 , $_SESSION['billFullname'] , 0, 0, "L");
            $this->Ln();
            $this->SetX(20);
            $this->Cell(50, 10 , "Email Address : ", 0, 0, "L");
            $this->Cell(120, 10 , $_SESSION['billEmail'] , 0, 0, "L");
            $this->Ln();
            $this->SetX(20);
            $this->Cell(50, 10 , "OrderID : ", 0, 0, "L");
            $this->Cell(120, 10 , $_SESSION['orderID'] , 0, 0, "L");
            $this->Ln();
            $this->header_line2();
        }

        function footer() {
            $this->header_line3();
            $this->setFont("Arial", "B", "18");
            $this->SetXY(55, 270);
            $this->Cell(100, 20, "Thank You for Purchasing Our Product", 0, 0, "C");
            $this->Ln();
            $this->SetY(-15);
            $this->setFont("Arial", "", "10");
            $this->Cell(0, 10, "Page " . $this->PageNo() . "/{nb}", 0, 0, "C");
        }

        function header_line() {
            $this->SetY(55);
            $this->setFillColor(136, 136, 136);
            $this->Cell(190, 2, "", 0, 0, "C", 1);
            $this->Ln();
        }

        function header_line2() {
            $this->SetY(92);
            $this->setFillColor(136, 136, 136);
            $this->Cell(190, 2, "", 0, 0, "C", 1);
            $this->Ln();
        }

        function header_line3() {
            $this->SetY(270);
            $this->setFillColor(136, 136, 136);
            $this->Cell(190, 2, "", 0, 0, "C", 1);
            $this->Ln();
        }

        function header_table($x) {
            $this->setFont("Times", "B", 14);
            $this->SetXY($x, 100);
            $this->Cell(10, 10 , "No.", 0, 0, "C");
            $this->Cell(100, 10 , "Item", 0, 0, "L");
            $this->Cell(20, 10 , "Quantity", 0, 0, "R");
            $this->Cell(40, 10 , "Price(RM)", 0, 0, "R");
            $this->Ln();
        }

        function header_data($x, $y) {
            $this->SetXY($x, $y);
            foreach ($_SESSION['array_product'] as $key => $value) {
                $this->SetX($x);
                $this->setFont("Times", "B", 12);
                $this->Cell(10, 10 , ($key + 1), 0, 0, "C");
                $this->Cell(100, 10 , $value, 0, 0, "L");
                $this->Cell(20, 10 , $_SESSION['array_quantity'][$key], 0, 0, "R");
                $this->Cell(40, 10 , number_format((float)$_SESSION['array_price'][$key], 2, '.', ''), 0, 0, "R");
                $this->Ln();
            }
            $this->Ln();
            $this->setFont("Times", "B", 12);
            $this->SetX($x);
            $this->Cell(130, 10 , "Total", 0, 0, "R");
            $this->Cell(40, 10 , number_format((float)$_SESSION['totalprice'], 2, '.', '') , 0, 0, "R");
            $this->Ln();
            $this->SetX($x);
            $this->Cell(130, 10 , "Tax(6%)", 0, 0, "R");
            $this->Cell(40, 10 , number_format((float)$_SESSION['totalprice'] * (float)$_SESSION['tax'], 2, '.', '') , 0, 0, "R");
            $this->Ln();
            $this->SetX($x);
            $this->Cell(130, 10 , "Amount Paid", 0, 0, "R");
            $this->Cell(40, 10 , number_format((float)$_SESSION['totalprice'] + ((float)$_SESSION['totalprice'] * (float)$_SESSION['tax']), 2, '.', '') , 0, 0, "R");
        }
    }
    $x = 20;
    $y = 110;
    $pdf = new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage("P", "A4", 0);
    $pdf->header_table($x);
    $pdf->header_data($x, $y);
    $pdf->Output();
?>
