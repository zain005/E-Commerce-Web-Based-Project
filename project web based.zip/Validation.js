function ValidateSignUp() {
	if(document.FormSignUp.Name.value == "") {
		alert("Name is required!");
		document.FormSignUp.Name.focus();
		return false;
	}

	if(!document.FormSignUp.Name.value.match(/^[a-zA-Z ]+$/)) {
		alert("Name should contain alphabets only!");
		document.FormSignUp.Name.focus();
		return false;
	}

	if(document.FormSignUp.MNumber.value == "") {
		alert("Mobile number is required!");
		document.FormSignUp.MNumber.focus();
		return false;
	}

	if(!document.FormSignUp.MNumber.value.match(/^[0-9]*$/)) {
		alert("Mobile number should contain numbers only!");
		document.FormSignUp.MNumber.focus();
		return false;
	}

	if(document.FormSignUp.Email.value == "") {
		alert("E-mail is required!");
		document.FormSignUp.Email.focus();
		return false;
	}

	if(!document.FormSignUp.Email.value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
		alert("You have entered an invalid email address!");
		document.FormSignUp.Email.focus();
		return false;
	}

	if(document.FormSignUp.Password.value == "") {
		alert("Password is required!");
		document.FormSignUp.Password.focus();
		return false;
	}

	if ((document.FormSignUp.Password.value.length < 6) || (document.FormSignUp.Password.value.length > 6)) {
		alert ("Password must be 6 digits!");
		document.FormSignUp.Password.focus();
		return false;
	}

	if (!document.FormSignUp.Password.value.match(/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*().,<>{}[\]?_=+\-|;:\'\"\/])/)) {
		alert ("Password should contain at least one numeric, uppercase letter, lowercase letter and special character!");
		document.FormSignUp.Password.focus();
		return false;
	}

	if (!document.FormSignUp.Password.value.match(/^([A-z0-9!@#$%^&*().,<>{}[\]?_=+\-|;:\'\"\/])*[^\s]\1*$/)) {
		alert ("No spaces are allowed in password!");
		document.FormSignUp.Password.focus();
		return false;
	}

	if (document.FormSignUp.CPassword.value == "") {
		alert ("Confirm your password!");
		document.FormSignUp.CPassword.focus();
		return false;
	}

	if (document.FormSignUp.Password.value != document.FormSignUp.CPassword.value) {
		alert ("Password does not match!");
		return false;
	}
}

function ValidateUpdateUser() {
	if(document.FormUpdateUser.Name.value == "") {
		alert("Name is required!");
		document.FormUpdateUser.Name.focus();
		return false;
	}

	if(!document.FormUpdateUser.Name.value.match(/^[a-zA-Z ]+$/)) {
		alert("Name should contain alphabets only!");
		document.FormUpdateUser.Name.focus();
		return false;
	}

	if(document.FormUpdateUser.MNumber.value == "") {
		alert("Mobile number is required!");
		document.FormUpdateUser.MNumber.focus();
		return false;
	}

	if(!document.FormUpdateUser.MNumber.value.match(/^[0-9]*$/)) {
		alert("Mobile number should contain numbers only!");
		document.FormUpdateUser.MNumber.focus();
		return false;
	}

	if(document.FormUpdateUser.Email.value == "") {
		alert("E-mail is required!");
		document.FormUpdateUser.Email.focus();
		return false;
	}

	if(!document.FormUpdateUser.Email.value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
		alert("You have entered an invalid email address!");
		document.FormUpdateUser.Email.focus();
		return false;
	}
}

function ValidatePayment() {
	if(document.FormBilling.firstname.value == "") {
		alert("Full Name is required!");
		document.FormBilling.firstname.focus();
		return false;
	}

	if(!document.FormBilling.firstname.value.match(/^[a-zA-Z ]+$/)) {
		alert("Name should contain alphabets only!");
		document.FormBilling.firstname.focus();
		return false;
	}

	if(document.FormBilling.email.value == "") {
		alert("E-mail is required!");
		document.FormBilling.email.focus();
		return false;
	}

	if(!document.FormBilling.email.value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
		alert("You have entered an invalid email address!");
		document.FormBilling.email.focus();
		return false;
	}

	if(document.FormBilling.address.value == "") {
		alert("Address is required!");
		document.FormBilling.address.focus();
		return false;
	}

	if(document.FormBilling.city.value == "") {
		alert("City is required!");
		document.FormBilling.city.focus();
		return false;
	}

	if(document.FormBilling.state.value == "") {
		alert("State is required!");
		document.FormBilling.state.focus();
		return false;
	}

	if(document.FormBilling.zip.value == "") {
		alert("Zip is required!");
		document.FormBilling.zip.focus();
		return false;
	}

	if(!document.FormBilling.zip.value.match(/^[0-9]*$/)) {
		alert("Your Zip should be numbers only!");
		document.FormBilling.zip.focus();
		return false;
	}

	if(document.FormBilling.cardname.value == "") {
		alert("Card Name is required!");
		document.FormBilling.cardname.focus();
		return false;
	}

	if(document.FormBilling.cardnumber.value == "") {
		alert("Card Number is required!");
		document.FormBilling.cardnumber.focus();
		return false;
	}

	if(!document.FormBilling.cardnumber.value.match(/^[0-9]*$/)) {
		alert("Your Card Number should be numbers only!");
		document.FormBilling.cardnumber.focus();
		return false;
	}

	if(document.FormBilling.expirymonth.value == "") {
		alert("Expiry Month is required!");
		document.FormBilling.expirymonth.focus();
		return false;
	}

	if(document.FormBilling.expiryyear.value == "") {
		alert("Expiry Year is required!");
		document.FormBilling.expiryyear.focus();
		return false;
	}

	if(!document.FormBilling.expiryyear.value.match(/^[0-9]*$/)) {
		alert("Your Expiry Year should be numbers only!");
		document.FormBilling.expiryyear.focus();
		return false;
	}

	if(document.FormBilling.cvv.value == "") {
		alert("CVV is required!");
		document.FormBilling.cvv.focus();
		return false;
	}

	if(!document.FormBilling.cvv.value.match(/^[0-9]*$/)) {
		alert("Your CVV should be numbers only!");
		document.FormBilling.cvv.focus();
		return false;
	}
}

function ValidateLogIn() {
	if(document.FormLogIn.emailLogin.value == "") {
	alert("E-mail is required!");
	document.FormLogIn.emailLogin.focus();
	return false;
	}

	if(!document.FormLogIn.emailLogin.value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
	alert("You have entered an invalid email address!");
	document.FormLogIn.emailLogin.focus();
	return false;
	}

	if(document.FormLogIn.passwordLogin.value == "") {
	alert("Password is required!");
	document.FormLogIn.passwordLogin.focus();
	return false;
	}
}

function PasswordToggle() {
	var x = document.getElementById("PasswordInput");
	var y = document.getElementById("ConfirmPassword");

	if (x.type === "password" && y.type === "password") {
		x.type = "text";
		y.type = "text";
	}
	else {
		x.type = "password";
		y.type = "password";
	}
}

function PasswordToggle2() {
	var x = document.getElementById("PasswordInput2");

	if (x.type === "password") {
		x.type = "text";
	}
	else {
		x.type = "password";
	}
}

function confirm_logout() {
	if (confirm("Are you sure you want to log out?")) {
		return true;
	}
	else {
		return false;
	}
}

function confirm_delete() {
	if (confirm("Are you sure you want to delete this item?")) {
		return true;
	}
	else {
		return false;
	}
}

function confirm_delete_user() {
	if (confirm("Are you sure you want to delete this registered user?")) {
		return true;
	}
	else {
		return false;
	}
}

function confirm_update_user() {
	if (confirm("Do you want to update this registered user?")) {
		return true;
	}
	else {
		return false;
	}
}

function confirm_empty() {
	if (confirm("Are you sure you want to empty this cart?")) {
		return true;
	}
	else {
		return false;
	}
}

function ValidateAddItem() {
	if(document.FormAddProduct.quantity.value == "") {
		alert("Please enter the quantity!");
		document.FormAddProduct.quantity.focus();
		return false;
	}
	else if (document.FormAddProduct.quantity.value == 0) {
		alert("Please enter the number more than zero!");
		document.FormAddProduct.quantity.focus();
		return false;
	}

	if(!document.FormAddProduct.quantity.value.match(/^[0-9]*$/)) {
		alert("You should input numbers only!");
		document.FormAddProduct.quantity.focus();
		return false;
	}
}
